$(function(){
    $('#date_of_birth').datepicker({
    	autoSize: true 
    });
});