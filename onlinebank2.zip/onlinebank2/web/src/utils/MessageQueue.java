package utils;

import java.util.ArrayList;

public class MessageQueue extends ArrayList<Message>{

}
